/**
 * Módulo Gofas Gerencinet Cartão para WHMCS
 * @author		Gofas Software
 * @see			https://gofas.net/?p=8423
 * @copyright	2016 - 2020 https://gofas.net
 * @license		https://gofas.net?p=9340
 * @support		https://gofas.net/?p=8343
 * @version		3.1.2
 */

$(function(){
    var ggncMaskBehavior = function (val){
      return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
    },
    ggncOptions = {
		onKeyPress: function(val, e, field, options){
 		field.mask(ggncMaskBehavior.apply({}, arguments), options);
 		}
    }
	ggncOptions2 = {
		placeholder: "(00) 00000-0000",
		onKeyPress: function(val, e, field, options){
 		field.mask(maskBehavior.apply({}, arguments), options);
 		}
    };
    $('#telefone').mask(ggncMaskBehavior, ggncOptions);
	$('#cep').mask('00000-000');
	$('#cpf').mask('000.000.000-00', {placeholder: "000.000.000-0"});
    $('#cnpj').mask('00.000.000/0000-00', {placeholder: "00.000.000/0000-00 (Opcional)"});
	$('#birthday').mask('00/00/0000', {placeholder: "DD/MM/AAAA"});
	$('#estado').mask( 'AA', {placeholder: "SP"});
  });